import yfinance as yf
import pandas as pd
import numpy as np
import plotly.graph_objects as go
import plotly.express as px
from plotly.subplots import make_subplots
import streamlit as st
from datetime import datetime, timedelta
from PIL import Image
import requests
import warnings
import os

# Ignore warnings
warnings.filterwarnings('ignore')

# --- PAGE CONFIGURATION ---
st.set_page_config(
    page_title="See Market | AI Terminal",
    page_icon="📈",
    layout="wide"
)

# --- CUSTOM CSS ---
st.markdown("""
    <style>
    /* 1. Fundo global e textos gerais */
    .stApp {
        background-color: #0A1F44;
    }
    .stApp, .stMarkdown, p, h1, h2, h3, h4, h5, h6 {
        color: #ffffff;
    }

    /* 2. SIDEBAR: Títulos "Enter Ticker" e "Period" em PRETO */
    /* Forçamos a cor preta em todos os labels e textos dentro da sidebar */
    section[data-testid="stSidebar"] label p {
        color: #000000 !important;
        font-weight: bold !important;
    }
    
    /* Título principal da Sidebar */
    section[data-testid="stSidebar"] h2 {
        color: #000000 !important;
    }

    /* 3. ABAS: Technical Analysis, Heatmap, News em PRETO */
    .stTabs [data-baseweb="tab"] p {
        color: #000000 !important;
        font-weight: bold !important;
    }

    /* 4. Inputs de texto: O que você digita também deve ser legível */
    .stTextInput input {
        color: #000000 !important;
    }

    /* 5. Estilização da Sidebar (Barra Lateral) */
    section[data-testid="stSidebar"] {
        background-color: #f0f9ff !important;
    }

    /* 6. Cards de conteúdo e métricas */
    [data-testid="stMetricValue"], .stPlotlyChart {
        background-color: #f0f9ff; 
        border-radius: 12px;
        box-shadow: 0 4px 6px -1px rgba(0, 0, 0, 0.1);
        padding: 15px;
        border: 1px solid #bae6fd;
    }
    
    /* Labels das Métricas (Price, Trend) em Branco no fundo azul */
    [data-testid="stMetricLabel"] p {
        color: #ffffff !important;
    }
    
    /* Valor numérico dentro do card em azul escuro */
    [data-testid="stMetricValue"] div {
        color: #0A1F44 !important;
    }

    /* Estilo das Tabs (cor de fundo) */
    .stTabs [data-baseweb="tab"] {
        background-color: #f0f9ff;
        border-radius: 8px 8px 0px 0px;
        border: 1px solid #bae6fd;
    }
    </style>
    """, unsafe_allow_html=True)

# --- CONSTANTS ---
NEWS_API_KEY = "00a213a0edd3410e86cbe9e0b5868637" 
BIG_TECHS = ['AAPL', 'MSFT', 'NVDA', 'GOOGL', 'AMZN', 'META', 'TSLA', 'AMD', 'NFLX', 'INTC']
LOGO_FILENAME = 'logo.png' 

class StockAnalyzer:
    def fetch_stock_data(self, symbol, period="1y"):
        try:
            stock = yf.Ticker(symbol)
            data = stock.history(period=period)
            if data.empty: return None, None
            if isinstance(data.columns, pd.MultiIndex):
                data.columns = data.columns.get_level_values(0)
            return data, stock.info
        except Exception as e:
            st.error(f"Error fetching data: {str(e)}")
            return None, None

    def calculate_indicators(self, data):
        df = data.copy()
        df['MA20'] = df['Close'].rolling(window=20).mean()
        df['MA50'] = df['Close'].rolling(window=50).mean()
        delta = df['Close'].diff()
        gain = (delta.where(delta > 0, 0)).rolling(window=14).mean()
        loss = (-delta.where(delta < 0, 0)).rolling(window=14).mean()
        df['RSI'] = 100 - (100 / (1 + (gain / loss)))
        df['Support'] = df['Low'].rolling(window=20).min()
        df['Resistance'] = df['High'].rolling(window=20).max()
        df['Returns'] = df['Close'].pct_change()
        df['Volatility'] = df['Returns'].rolling(window=20).std() * np.sqrt(252)
        return df

    def get_market_pattern(self, df):
        last_close = df['Close'].iloc[-1]
        ma20 = df['MA20'].iloc[-1]
        if last_close > ma20:
            return "Bullish Trend", ""
        elif last_close < ma20:
            return "Bearish Trend", ""
        return "Sideways", ""

def create_main_chart(df, symbol):
    fig = make_subplots(rows=2, cols=1, shared_xaxes=True, 
                       vertical_spacing=0.05, row_heights=[0.7, 0.3])
    fig.add_trace(go.Candlestick(
        x=df.index, open=df['Open'], high=df['High'], 
        low=df['Low'], close=df['Close'], name='Price'
    ), row=1, col=1)
    
    fig.add_trace(go.Scatter(x=df.index, y=df['MA20'], line=dict(color="#7030E0", width=2), name='MA20'), row=1, col=1)
    fig.add_trace(go.Scatter(x=df.index, y=df['Support'], line=dict(color='#10b981', dash='dot'), name='Support'), row=1, col=1)
    fig.add_trace(go.Scatter(x=df.index, y=df['Resistance'], line=dict(color='#ef4444', dash='dot'), name='Resistance'), row=1, col=1)
    
    fig.add_trace(go.Bar(x=df.index, y=df['Volume'], name='Volume', marker_color="#024699", opacity=0.6), row=2, col=1)
    
    fig.update_layout(
        height=650, template='plotly_dark', xaxis_rangeslider_visible=False,
        margin=dict(l=10, r=10, t=10, b=10),
        paper_bgcolor='rgba(0,0,0,0)', plot_bgcolor='rgba(0,0,0,0)',
        legend=dict(orientation="h", yanchor="bottom", y=1.02, xanchor="right", x=1)
    )
    return fig

def main():
    if os.path.exists(LOGO_FILENAME):
        try:
            logo_img = Image.open(LOGO_FILENAME)
            st.image(logo_img, width=250)
        except:
            st.markdown('<h1>🚀 See Market</h1>', unsafe_allow_html=True)
    else:
        st.markdown('<h1>🚀 See Market</h1>', unsafe_allow_html=True)

    analyzer = StockAnalyzer()
    
    st.sidebar.markdown("## 🔍 Search")
    symbol = st.sidebar.text_input("Enter Ticker", value="AAPL").upper()
    time_range = st.sidebar.selectbox("Period", ["1mo", "3mo", "6mo", "1y", "2y", "5y"], index=3)
    
    data, info = analyzer.fetch_stock_data(symbol, time_range)
    
    if data is not None:
        df = analyzer.calculate_indicators(data)
        
        m1, m2, m3, m4 = st.columns(4)
        with m1:
            st.metric("Price", f"${df['Close'].iloc[-1]:.2f}", f"{df['Returns'].iloc[-1]:.2%}")
        with m2:
            pattern, icon = analyzer.get_market_pattern(df)
            st.metric("Trend", pattern, icon)
        with m3:
            pos_days = (df['Returns'].dropna() > 0).sum()
            prob = (pos_days / len(df['Returns'].dropna())) * 100
            st.metric("Prob. Increase", f"{prob:.1f}%")
        with m4:
            st.metric("Vol (Ann.)", f"{df['Volatility'].iloc[-1]:.1%}")

        tab_main, tab_heat, tab_news = st.tabs(["Technical Analysis", "Heatmap", "News"])
        
        with tab_main:
            st.plotly_chart(create_main_chart(df, symbol), use_container_width=True)
            st.subheader("7-Day Price Forecast")
            last_p = df['Close'].iloc[-1]
            avg_ret = df['Returns'].mean()
            forecast = [last_p * (1 + avg_ret)**i for i in range(1, 8)]
            f_dates = [df.index[-1] + timedelta(days=i) for i in range(1, 8)]
            fig_p = px.line(x=f_dates, y=forecast, labels={'x':'Date', 'y':'Price'}, markers=True)
            fig_p.update_traces(line_color="#38bdf8")
            fig_p.update_layout(template='plotly_dark', height=350, paper_bgcolor='rgba(0,0,0,0)', plot_bgcolor='rgba(0,0,0,0)')
            st.plotly_chart(fig_p, use_container_width=True)

        with tab_heat:
            st.subheader("Global Tech Performance (5D)")
            h_data_list = []
            for t in BIG_TECHS:
                try:
                    h_close = yf.download(t, period="5d", progress=False)['Close']
                    if isinstance(h_close, pd.DataFrame): h_close = h_close.iloc[:,0]
                    change = ((h_close.iloc[-1] - h_close.iloc[0]) / h_close.iloc[0]) * 100
                    h_data_list.append({'Ticker': t, 'Change %': change})
                except: continue
            if h_data_list:
                h_df = pd.DataFrame(h_data_list)
                fig_h = px.bar(h_df, x='Ticker', y='Change %', color='Change %', color_continuous_scale='RdYlGn')
                fig_h.update_coloraxes(cmid=0)
                fig_h.update_layout(template='plotly_dark', paper_bgcolor='rgba(0,0,0,0)', plot_bgcolor='rgba(0,0,0,0)')
                st.plotly_chart(fig_h, use_container_width=True)

        with tab_news:
            st.subheader(f"Latest News: {symbol}")
            url = f'https://newsapi.org/v2/everything?q={symbol}&apiKey={NEWS_API_KEY}&language=en&pageSize=5'
            try:
                articles = requests.get(url).json().get('articles', [])
                for art in articles:
                    st.markdown(f"**[{art['title']}]({art['url']})**")
                    st.write(f"{art['description']}")
                    st.divider()
            except: st.error("Error fetching News.")
    else:
        st.error("Ticker not found.")

if __name__ == "__main__":
    main()